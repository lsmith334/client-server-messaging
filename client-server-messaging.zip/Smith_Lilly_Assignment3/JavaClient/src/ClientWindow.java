import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.Timer;

import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.net.*;
import java.util.Scanner;
import java.io.*;

public class ClientWindow extends JFrame implements ActionListener {

	private static JPanel contentPane;
	public static JTextField txtInput;
	public static JTextArea txtMessages;
	public static JTextArea txtName;
	
	static String serverName  = "localhost";								// Establish the local machine as the server
	static int port = 6066;													// Hard-code port for connection
	
    static Socket client;
    static OutputStream outToServer;
    static DataOutputStream out;
    static InputStream inFromServer;
    static DataInputStream in;
	
	private static String userMessage = "";
	private static String messageList = "";
	public static String userID = "";
	public static byte currentColour = 0;
	
	private static final Integer FRAMETIME = 1000;
	
	private Timer tickTock = new Timer(FRAMETIME,this);									// instantiate a timer object
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		userID = JOptionPane.showInputDialog("Please enter your name:");		//collect input
		JOptionPane.showMessageDialog(null, "Hello, " + userID);
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientWindow frame = new ClientWindow();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClientWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		txtInput = new JTextField();
		txtInput.setBounds(10, 381, 416, 30);
		contentPane.add(txtInput);
		txtInput.setColumns(10);
		txtInput.setText("");
		
		txtMessages = new JTextArea();
		txtMessages.setEditable(false);
		txtMessages.setBackground(Color.GRAY);
		txtMessages.setBounds(10, 40, 416, 330);
		contentPane.add(txtMessages);
		
		JButton btnSend = new JButton("Send Message");
		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//call message update function
				
				sendMessage();

			}
		});
		btnSend.setBounds(10, 422, 198, 30);
		contentPane.add(btnSend);
		
		JButton btnMode = new JButton("Change Mode");
		btnMode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//call mode change function
				setFrameColour();
				
			}
		});
		btnMode.setBounds(228, 422, 198, 30);
		contentPane.add(btnMode);
		
		txtName = new JTextArea();
		txtName.setEditable(false);
		txtName.setText("User: " + userID);
		txtName.setBackground(Color.GRAY);
		txtName.setBounds(10, 11, 416, 22);
		contentPane.add(txtName);
		
		tickTock.start();																	// start the timer
		
	}
	
	public static void setText(String messages)
	{
		txtMessages.setText(messages);										//set textarea
	}
	
	public static void setFrameColour()
	{
		if (currentColour == 0)
		{
			contentPane.setBackground(Color.LIGHT_GRAY);
			txtMessages.setBackground(Color.WHITE);
			txtName.setBackground(Color.WHITE);
			currentColour = 1;
		}
		else if (currentColour == 1)
		{
			contentPane.setBackground(Color.RED);
			txtMessages.setBackground(Color.PINK);
			txtName.setBackground(Color.PINK);
			currentColour = 2;
		}
		else if (currentColour == 2)
		{
			contentPane.setBackground(Color.DARK_GRAY);
			txtMessages.setBackground(Color.GRAY);
			txtName.setBackground(Color.GRAY);
			currentColour = 0;
		}
		
	}
	
	public static void sendMessage()
	   {
		
		userMessage = txtInput.getText();									//collect user input
		
		try {
			
			client = new Socket(serverName, port);							//establish a connection
			
			outToServer = client.getOutputStream();
			out = new DataOutputStream(outToServer);
			
			out.writeUTF(userID + ": " + userMessage);						//sending data to server
			txtInput.setText("");
			
			inFromServer = client.getInputStream();
			in = new DataInputStream(inFromServer);
			
			messageList = in.readUTF();										//reading returned data from server
			//System.out.println(messageList);		
			txtMessages.setText(messageList);
			
			client.close();													//close connection
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
	
	public static void updateMessages()
	{
		
		try {
			
			client = new Socket(serverName, port);							//establish a connection
			
			outToServer = client.getOutputStream();
			out = new DataOutputStream(outToServer);
			
			out.writeUTF("");												//sending data to server
			
			inFromServer = client.getInputStream();
			in = new DataInputStream(inFromServer);
			
			messageList = in.readUTF();										//reading returned data from server
			//System.out.println(messageList);
			txtMessages.setText(messageList);
			
			client.close();													//close connection
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		updateMessages();
		
	}
	
}
